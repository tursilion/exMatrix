20030618

EXMatrix Screen Saver for Windows

Because Microsoft is evil, apparently, this software exists. ;)

Anyway, to use this, copy it into your Windows folder (either C:\Windows or C:\WINNT on most machines, for 2000 and XP put it in \Windows\System32 or \Winnt\System32 depending on which you have). 

Then it will show up in your Display properties for Screen-Savers, just like any other, and you can select and configure it at will.

This SHOULD run on anything from Win98 up - still working fine on Windows 11!

